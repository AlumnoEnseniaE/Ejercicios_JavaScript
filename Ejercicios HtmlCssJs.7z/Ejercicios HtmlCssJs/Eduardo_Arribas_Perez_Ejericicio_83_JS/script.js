﻿window.addEventListener("resize", function() {
	
   parrafo.innerHTML = "La ventana del navegador se ha redimensionado : "+innerWidth+"x"+innerHeight;

});