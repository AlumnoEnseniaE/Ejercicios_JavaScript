function edad() {
	
	var edad = parseInt(document.getElementById("edad").value)

	 while (edad < 1 || edad > 17) {
		alert("Edad no v�lida. Introduzca una edad entre 1 y 17 a�os.");
		edad = parseInt(prompt("Por favor, introduzca su edad nuevamente:"));
	} 
	  alert("�Gracias! Su edad es " + edad + " a�os.");
}