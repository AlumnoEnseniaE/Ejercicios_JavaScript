﻿function calcular(){
	
const numeros = [5,6,7,6,5,6,7,8];

	const numeroElementosRepetidos = numeros.reduce((acumulador, elementoActual) => { 
		
		acumulador[elementoActual] = (acumulador[elementoActual] || 0) + 1;
		
		return acumulador;
		
	}, {});
	
	document.getElementById('parrafo').innerHTML = 'Los numeros del array son: '+ numeros.join();
	console.log(numeroElementosRepetidos);

}