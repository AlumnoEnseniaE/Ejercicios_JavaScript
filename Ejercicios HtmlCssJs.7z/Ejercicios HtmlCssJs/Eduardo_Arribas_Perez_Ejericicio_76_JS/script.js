﻿window.onload = function(){
	alert('La pagina se ha cargado completamente');
}

window.onbeforeunload = function(){
	return "¿Estas seguro de que quieres abandonar la página web?";
}
/*
No funciona en los navegadores actuales.
window.onunload = function(){
	alert('La página se está cargando');
}*/
function cerrar (){
	window.close();
}