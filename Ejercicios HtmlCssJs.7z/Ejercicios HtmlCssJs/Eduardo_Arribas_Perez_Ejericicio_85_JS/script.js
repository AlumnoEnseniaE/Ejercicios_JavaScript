﻿img.onerror = function(){
	alert('Fallo de imagen');
	console.log("error");
	img.src = 'img2.jpg';
}
