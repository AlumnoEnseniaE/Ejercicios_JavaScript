﻿var vocal = document.addEventListener("keypress", teclas);

function teclas(vocal) {
	
  if ( vocal.key === 'a' || vocal.key === 'e' || vocal.key === 'i' || vocal.key === 'o' || vocal.key === 'u') {
    parrafo.innerHTML = "Letra aceptada : " + vocal.key;
  }else if( vocal.key === 'A' || vocal.key === 'E' || vocal.key === 'I' || vocal.key === 'O' || vocal.key === 'U'){
	  parrafo.innerHTML = "Letra aceptada : " + vocal.key;
  }else{
	  parrafo.innerHTML = "Error letra no encontrada: "+vocal.key;
  }
}
	