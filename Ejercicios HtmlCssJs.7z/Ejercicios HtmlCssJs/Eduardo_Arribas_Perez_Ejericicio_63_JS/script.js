var numeros = [];

window.onload = function(){
	for (var i=0; i<=15;i++){
		numeros[i] = Math.floor(Math.random() * 100)+1;;
	}
	parrafo.innerHTML = numeros; 
}

function ordenar() {
	
	let tama�oArray=0;
	let	aux=0;
    
	tama�oArray = numeros.length;

    for (var i = 1; i < tama�oArray; i++) {
		
        for (var j = 0; j < (tama�oArray - i); j++) {
			
            if (numeros[j] > numeros[j + 1]) {
                aux = numeros[j];
                numeros[j] = numeros[j + 1];
                numeros[j + 1] = aux;
            }
        }
    }
	

	/*
--------------------- Version Profesor --------------------
	
	let tama�oArray=0;
	let	aux=0;
    
	tama�oArray = numeros.length;
    for (var i = 0; i < tama�oArray; i++) {
		
        for (var j = 0; j < (tama�oArray - i - 1); j++) {
			
            if (numeros[j] > numeros[j + 1]) {
                aux = numeros[j];
                numeros[j] = numeros[j + 1];
                numeros[j + 1] = aux;
            }
        }
    }
--------------------- metodo short ---------------
	numeros.sort((a, b) => a - b);
	parrafo1.innerHTML = numeros;*/
}
 