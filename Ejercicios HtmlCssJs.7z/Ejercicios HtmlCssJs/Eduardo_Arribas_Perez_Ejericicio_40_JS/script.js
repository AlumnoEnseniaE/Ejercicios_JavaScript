function comprobar(){
	const num1 = document.getElementById("entrada").value;
	const parrafo = document.getElementById("parrafo");
	var resultado="";

	for(i=1;i<=10;i++){
    var tabla = num1 * i;
     resultado=resultado.concat(num1, "X", i, "=", tabla, "<br>");
     parrafo.innerHTML= resultado;
		
	}

}