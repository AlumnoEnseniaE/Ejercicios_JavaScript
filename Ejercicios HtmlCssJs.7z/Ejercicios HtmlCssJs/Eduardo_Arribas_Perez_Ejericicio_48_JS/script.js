let numeros = [];
let salir = "salir"

function infinitos() {

	let num1 = document.getElementById("entrada").value;



	if (num1 === salir) {
		parrafo.innerHTML = 'Fin del programa';
	} else {

		let num2 = parseInt(num1, 10);
		numeros.push(num2);
	}

	  document.getElementById("entrada").value = "";

}