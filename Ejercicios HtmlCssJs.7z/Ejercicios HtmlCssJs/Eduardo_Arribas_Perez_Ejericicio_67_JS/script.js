﻿function calcular(){
	const numeros = [5,4,8,6,2];
	let acumulador = 0;
	
	for(let i = 0; i<numeros.length; i++){
		const numero = numeros[i];
		acumulador = acumulador + numero**2;
	}
	document.getElementById('parrafo').innerHTML = 'Los numeros del array son: '+ numeros.join();
	document.getElementById('parrafo1').innerHTML = 'La suma de los cuadrados es: ' +acumulador;
	/*El metodo .join() crea y devuelve una nueva cadena de datos al concatenar todos los elementos del array
	si solo tiene un elemento lo devuelve sin el separador (,) */
}