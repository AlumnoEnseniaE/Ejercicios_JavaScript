function tablasMultiplicar(){
	
var resultado="";
var tabla = 0;
	for(i=1;i<=10;i++){
		
		resultado += "<h2>Tabla del "+i+"</h2>";
		for(j=1; j<=10;j++){
			
			tabla=i*j;
			
			resultado=resultado.concat(i, "X", j, "=", tabla, "<br>");

			
			parrafo.innerHTML= resultado;
			
		}
			
	}
}
			

