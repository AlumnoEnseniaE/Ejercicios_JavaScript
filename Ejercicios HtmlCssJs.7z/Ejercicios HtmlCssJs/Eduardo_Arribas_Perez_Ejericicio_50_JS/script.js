function jugar() {
	
	 let jugador1 = parseInt(document.getElementById("jugador1").value);
	 let jugador2 = parseInt(document.getElementById("jugador2").value);
	 
	 if(jugador1 === jugador2){
		 parrafo.innerHTML = 'Empate';
	 }else if(jugador1 === 1  && jugador2===2){
		 parrafo.innerHTML = 'Gana jugador 2';
	 }else if(jugador1 === 1  && jugador2===3){
		  parrafo.innerHTML = 'Gana jugador 1';
	 }else if(jugador1 === 2  && jugador2===1){
		  parrafo.innerHTML = 'Gana jugador 1';
	 }else if(jugador1 === 2  && jugador2===3){
		  parrafo.innerHTML = 'Gana jugador 2';
	 }else if(jugador1 === 3  && jugador2===2){
		  parrafo.innerHTML = 'Gana jugador 1';
	 }else if(jugador1 === 3  && jugador2===1){
		  parrafo.innerHTML = 'Gana jugador 2';
	 }

}