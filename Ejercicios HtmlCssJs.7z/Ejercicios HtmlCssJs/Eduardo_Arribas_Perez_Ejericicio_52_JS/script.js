function semaforo() {
	
	 let color = document.getElementById("color").value.toLowerCase().trim();
	 console.log(color);

	switch (color){	  
	  case "rojo":{
		parrafo.innerHTML = 'El semaforo esta en Rojo';
	  break;
	  }	
	  case "ambar":{
		parrafo.innerHTML = 'El semaforo esta en Ambar';
	  break; 
	  }
	  case "verde": {
		parrafo.innerHTML = 'El semaforo esta en Verde';
	  break;
	  }
	  default:{
		parrafo.innerHTML = 'Es semaforo esta roto y no fuenciona Cuidado'
	  break;
	  }
	}
}
