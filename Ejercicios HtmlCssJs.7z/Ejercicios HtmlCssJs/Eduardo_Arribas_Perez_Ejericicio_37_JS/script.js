function par(){
	const num1 = document.getElementById("entrada");
	const parrafo = document.getElementById("parrafo");
	const num2 = parseInt(num1.value, 10);
	
	if(num2<0){
		 parrafo.innerHTML = 'El n�mero introducido es Negativo';
	}else if(num2%2===0){
		 parrafo.innerHTML = 'El n�mero introducido es Par';
	}else{
		 parrafo.innerHTML = 'El n�mero introducido es Impar';
	}
}

