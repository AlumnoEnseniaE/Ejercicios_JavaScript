window.onload = function(){
	mostrar();
}
function mostrar() {
	let contador=1;
	let resultado="";
	while(contador!=11){
		resultado=resultado.concat("El numero: ",contador,"<br>");
		parrafo.innerHTML= resultado;
		contador++;
	}

}