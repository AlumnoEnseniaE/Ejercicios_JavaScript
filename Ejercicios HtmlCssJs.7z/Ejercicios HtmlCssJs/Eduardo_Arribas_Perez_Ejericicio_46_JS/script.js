function multiplicar3() {
let multiplicacion=1;

  let num1 = parseInt(document.getElementById("numero1").value);
  let num2 = parseInt(document.getElementById("numero2").value);
  let num3 = parseInt(document.getElementById("numero3").value);

  multiplicacion=num1*num2*num3;
  
    parrafo.innerHTML = 'La multiplicacion total de numeros es: ' + multiplicacion;

}