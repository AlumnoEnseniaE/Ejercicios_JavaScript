﻿function mostrar(){	
	alert('Has pinchado en la 1º foto de la imagen');
}
function mostrar1(){	
	alert('Me has pinchado 2 veces >.< eso duele');
}

function mostrar2(){
	alert('Me estas pulsando mucho tiempo ....');
}

function mostrar3(){
	alert('Estas paseando por encima de mí');
}

function mostrar4(){
	alert('Gracias por dejar de pulsarme ');
}

function mostrar5(){
	alert('Estas por encima de esta foto ');
}

function mostrar6(){
	alert('Acabas de salir de la foto');
}

