﻿const arrastrar = document.getElementById("drag");
const contenedor = document.getElementById("drop");

function dragStart(pinchar){
	pinchar.dataTransfer.setData("text/plain", pinchar.target.id);
	
}
function dragOver(mover){
	mover.preventDefault();
}
function dropHandler(soltar){
	soltar.preventDefault();
	const data = soltar.dataTransfer.getData("text/plain");
	console.log(data);	
	/*
------------ version profesor ------------------
	const mover = document.getElementById(data);
	event.target.appendChild(mover);
	mover.style.display = 'none';
	*/
	principal = drag.parentNode;
	principal.removeChild(drag);
	
}

arrastrar.addEventListener("dragstart", dragStart);
contenedor.addEventListener("dragover", dragOver);
contenedor.addEventListener("drop",dropHandler);