﻿function comprobar() {
	const n = document.getElementById("numero");
	const parrafo = document.getElementById("parrafo");
	const n2 = parseInt(n.value, 10);
	
if (n2 > 0) {
	 parrafo.innerHTML = 'El número introducido es positivo';
	
}else if (n2 < 0) { 

	 parrafo.innerHTML = 'El número introducido es negativo';
}else{ 
 
	 parrafo.innerHTML = 'El número introducido es cero';
	} 
}
