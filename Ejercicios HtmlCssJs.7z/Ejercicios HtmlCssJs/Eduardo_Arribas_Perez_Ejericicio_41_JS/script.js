let numeros = [];
let suma=0;

function agregar(){
	
	let num1 = parseInt(document.getElementById("entrada").value);

	if(num1 ===0){
		for (let i=0;i< numeros.length;i++){
			suma+=numeros[i];
		}
		parrafo.innerHTML = 'La suma total de numeros es: '+suma;
	}else{
		numeros.push(num1);
	}
		document.getElementById("entrada").value="";
		
		
}