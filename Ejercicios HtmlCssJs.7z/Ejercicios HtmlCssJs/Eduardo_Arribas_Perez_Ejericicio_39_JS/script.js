function comprobar(){
	const num1 = document.getElementById("entrada");
	const parrafo = document.getElementById("parrafo");
	const num2 = parseInt(num1.value, 10);
	var acumulador ="";
	
	if(num2< 1 || num2>10){
		 parrafo.innerHTML = 'Error numero incorrecto , vuelve a introducir un numero';
		 
	}else{
		for (var i=1; i<=num2; i++){
			acumulador=acumulador+' '+i;
			console.log(acumulador);
			parrafo.innerHTML = 'Numeros del 1 al '+num2+' es: '+acumulador;
				
		}
	}

	
	
}