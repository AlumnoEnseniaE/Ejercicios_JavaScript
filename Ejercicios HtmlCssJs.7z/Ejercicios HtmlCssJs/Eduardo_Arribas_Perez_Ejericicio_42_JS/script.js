function diasSemana(){
	
	let num1 = parseInt(document.getElementById("entrada").value);

	if(num1>=1 && num1<=7){
		
	  switch (num1) {
		case 1:
			parrafo.innerHTML = 'El dia de la semana es: Lunes';
		  break;
		case 2:
			parrafo.innerHTML = 'El dia de la semana es: Martes';
		  break;
		case 3:
			parrafo.innerHTML = 'El dia de la semana es: Miercoles';
		  break;
		case 4:
		  parrafo.innerHTML = 'El dia de la semana es: Jueves';
		  break;		
		case 5:
		  parrafo.innerHTML = 'El dia de la semana es: Viernes';
		  break;		  
		case 6:
		  parrafo.innerHTML = 'El dia de la semana es: Sabado';
		  break;		  
		case 7:
		  parrafo.innerHTML = 'El dia de la semana es: Domingo';
		  break;
	  }
	}else{
		 parrafo.innerHTML = 'El numero introducido no es valido , es de 1 a 7';
	}
}