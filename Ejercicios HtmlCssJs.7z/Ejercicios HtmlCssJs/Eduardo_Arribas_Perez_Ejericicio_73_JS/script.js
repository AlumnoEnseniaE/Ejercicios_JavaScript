﻿function calcular(){
	
	const numeros = [];
	
	for (let i = 0; i < 10 ;i++){
		numeros[i] = Math.floor(Math.random() * 10)+1;
	}
	
	const numeroElementosRepetidos = numeros.reduce((numero, elemento) => {
		if(!numero[elemento]){
			numero[elemento] = 1;
		}else{
			numero[elemento] = numero[elemento] + 1;
		}
		return numero;
	},{});
	document.getElementById('parrafo').innerHTML = 'Los numeros del array son: '+ numeros.join();
	console.log(numeroElementosRepetidos);
}