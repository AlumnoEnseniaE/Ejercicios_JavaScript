function doblar() {
	let doble=0;
	let num1 = parseInt(document.getElementById("numero1").value);

	if(num1<0){
		parrafo.innerHTML = 'El numero es negativo error';
	}else{
		doble=num1*2;
		parrafo.innerHTML = 'El numero doblado es '+doble;
	}

}