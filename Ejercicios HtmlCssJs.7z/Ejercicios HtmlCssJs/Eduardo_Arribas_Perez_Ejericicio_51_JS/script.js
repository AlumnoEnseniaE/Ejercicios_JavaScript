function descuento(){
	
	 let articulo = parseInt(document.getElementById("articulo").value);
	 let precio = parseInt(document.getElementById("precio").value);

  if(articulo<=5){
    let porcent=(articulo*precio)-((articulo*precio)*0.1);
    parrafo.innerHTML = 'El precio total con el descuento es :'+porcent;

  }else if(articulo>=6 && articulo<=10){
    let porcent = (articulo * precio) - ((articulo * precio) * 0.15);
     parrafo.innerHTML = 'El precio total con el descuento es :'+porcent;

  }else{
    let porcent = (articulo * precio) - ((articulo * precio) * 0.2);
     parrafo.innerHTML = 'El precio total con el descuento es :'+porcent;

  }
}
