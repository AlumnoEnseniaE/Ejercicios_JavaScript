﻿var vocal = document.addEventListener("keypress", teclas);

function teclas(vocal) {
	
  if ((vocal.key >='a' && vocal.key <='z') || (vocal.key >='A' && vocal.key <='Z' ) || (vocal.key >='0' && vocal.key <='9') || (vocal.key === 'ñ' || vocal.key === 'Ñ')) {
   
   parrafo.innerHTML = "Letra esta dentro del abecedario y/o rango de numeros : " + vocal.key;
  
  }else{
	  parrafo.innerHTML = "ERROR TECLA EQUIVOCADA: "+vocal.key;
  }
}
/*
---------- version 1 --------
var vocal = document.addEventListener("keypress", teclas);

const letras = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "ñ", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x" , "y" , "z","A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "Ñ", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];

function teclas(vocal) {
	
  let abecedario = letras.some(letra => letra == vocal.key);
  let valor = vocal.key;

  if (abecedario === true)  {
    parrafo.innerHTML = "Letra esta dentro del abecedario y/o rango de numeros : " + vocal.key;
  } else {  
    parrafo.innerHTML = "ERROR TECLA EQUIVOCADA: " + vocal.key;
  }
}
---------- version 2 --------
var vocal = document.addEventListener("keypress", teclas);

var letras = /^[0-9a-zA-Z]$/;

function teclas(vocal) {

  let valor = vocal.key.match(letras);
 
  if (valor !== null) {
    parrafo.innerHTML = "Letra esta dentro del abecedario y/o rango de numeros : " + vocal.key;
  }
  else {
    parrafo.innerHTML = "ERROR TECLA EQUIVOCADA: " + vocal.key;
  }
}
*/
	