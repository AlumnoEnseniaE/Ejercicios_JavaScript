﻿function calcular(){

	const numeros = [5,6,7,6,7,9,8,7,9,8,1];
	
	const numeroElementosRepetidos = numeros.reduce((numero, elemento) => {
		if(!numero[elemento]){
			numero[elemento] = 1;
		}else{
			numero[elemento] = numero[elemento] + 1;
		}
		return numero;
	},{});
	document.getElementById('parrafo').innerHTML = 'Los numeros del array son: '+ numeros.join();
	console.log(numeroElementosRepetidos);
	
}