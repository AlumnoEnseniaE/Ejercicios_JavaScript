﻿const productos =[
{title:'Hamburguesa',price:15},
{title:'Pizza',price:12},
{title:'Hotdog',price:9},
]
const app = document.getElementById('app');
const ul = app.querySelector('ul');

	productos.forEach(producto => {
		const li = document.createElement('li');
		li.innerHTML = `${producto.title} - <span>${producto.price}€</span>`;
		ul.appendChild(li);
	});
/*
function forEach(){
	productos.forEach(producto => {
		const li = document.createElement('li');
		li.innerHTML = `${producto.title} - <span>${producto.price}€</span>`;
		ul.appendChild(li);
	});
}
Esto seria si usaramos un boton en el html para que muestre los datos.
*/ 