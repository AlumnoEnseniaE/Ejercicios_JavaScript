﻿function calcular(){
	const numeros = [5,4,8,6,2];
	let sumar = 0;
	
	const numerosNuevos = numeros.reduce((sumar,numero)=> (sumar + numero**2),0);

	document.getElementById('parrafo').innerHTML = 'Los numeros del array son: '+ numeros.join();
	document.getElementById('parrafo1').innerHTML = 'La suma de los cuadrados es: ' +numerosNuevos;
}