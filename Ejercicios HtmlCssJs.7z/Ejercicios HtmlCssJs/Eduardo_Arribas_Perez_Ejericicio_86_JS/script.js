﻿img.addEventListener("abort", function() {

	alert('Fallo de carga en la imagen');
	console.log("error");

	
});	
