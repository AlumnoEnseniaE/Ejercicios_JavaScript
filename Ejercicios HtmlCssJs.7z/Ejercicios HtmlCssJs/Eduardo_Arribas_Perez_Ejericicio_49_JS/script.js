function factorial() {

  var resultado = 1;

  let num1 = parseInt(document.getElementById("entrada").value);

  if (num1 === 0 || num1 === 1) {

    parrafo.innerHTML = 'No tiene factoriales';

  } else {
    
    for (i = 1; i <= num1; i++) {
      resultado = resultado * i;
    }
    parrafo.innerHTML = 'El factorial del ' + num1 + ' es :' + resultado;
  }
}