function primos(){
	
	let primo=true;
	let num1 = parseInt(document.getElementById("entrada").value);

	for(let i=2;i<num1;i++){
		if(num1%i ==0){
		  primo=false;
		}
	 }
	if(primo==true){
		parrafo.innerHTML = 'El numero introducido es Primo'; 
	}else{
		parrafo.innerHTML = 'El numero introducido es No Primo'; 
	}

}
