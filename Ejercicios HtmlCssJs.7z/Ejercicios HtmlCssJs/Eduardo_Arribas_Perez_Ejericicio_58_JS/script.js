window.onload = function(){
	mostrar();
}
function mostrar() {
	let resultado="";
	for(var i=1;i<=10;i++){
		resultado=resultado.concat("El numero: ", i,"<br>");
		parrafo.innerHTML= resultado;
	}

	
}