window.onload = function(){
	mostrarArray();
}
function mostrarArray() {
	var resultado="";
	var nombres = [];
		var indice = nombres.length;
		nombres[0] = "Eduardo";
		nombres[1] = "Ilsina";
		nombres[2] = "Javier";
		nombres[3] = "Jose";
		nombres[4] = "George";
		nombres[5] = "Raul";
		nombres[6] = "Maria";
		nombres[7] = "Nathaly";
		nombres[8] = "Ariana";
		nombres[9] = "Luz Maria";
		nombres[10] = "Alejandro";
		
	for (var i=0;i<=nombres.length-1;i++){
		
		resultado=resultado.concat("El alumno es: ", nombres[i],"<br>");
		parrafo.innerHTML= resultado;
	}

}