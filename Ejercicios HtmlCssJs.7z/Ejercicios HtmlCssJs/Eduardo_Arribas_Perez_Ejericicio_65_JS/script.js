﻿document.querySelector("#callback-btn").addEventListener("click",function(){
	parrafo.innerHTML="Has hecho click en el boton indicado";
	console.log("Has echo click en el boton indicado");
});