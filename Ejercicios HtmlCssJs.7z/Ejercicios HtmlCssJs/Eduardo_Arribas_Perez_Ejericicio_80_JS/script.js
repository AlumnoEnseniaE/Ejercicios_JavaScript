﻿document.addEventListener("keydown", function(vocal) {
	
   parrafo.innerHTML = "El codigo de la tecla pulsada es : " + vocal.code;
  
});