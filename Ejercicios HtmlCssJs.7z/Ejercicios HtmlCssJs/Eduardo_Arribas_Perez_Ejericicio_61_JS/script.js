function areaCiruculo() {
	const pi = Math.PI;
	var radioCirculo=0;
	var areaCiruculo = 0;
	
	let num1 = parseFloat(document.getElementById("radio").value);
	radioCirculo = Math.pow(num1,2);
	areaCiruculo = pi*radioCirculo;
	parrafo.innerHTML = 'El area del circulo es :'+areaCiruculo.toFixed(2);

}