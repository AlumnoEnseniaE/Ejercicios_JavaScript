﻿function calcular(){
	
	const numeros = [];
	
	for (let i = 0; i < 10 ;i++){
		numeros[i] = Math.floor(Math.random() * 10)+1;
	}
	
	const numeroElementosRepetidos = numeros.reduce((acumulador, elementoActual) => { 
		
		acumulador[elementoActual] = (acumulador[elementoActual] || 0) + 1;
		
		return acumulador;
		
	}, {});
	
	document.getElementById('parrafo').innerHTML = 'Los numeros del array son: '+ numeros.join();
	console.log(numeroElementosRepetidos);
}