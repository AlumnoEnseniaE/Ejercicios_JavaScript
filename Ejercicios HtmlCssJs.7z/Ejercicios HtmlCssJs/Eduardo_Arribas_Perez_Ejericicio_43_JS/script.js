document.getElementById('inputArchivo').addEventListener('change', function(evento) {
		
		let archivo = evento.target.files[0];
		
		let contenido = document.getElementById('parrafo');
	
		
		if (archivo) {
			let lector = new FileReader();

						
			lector.onload = function(e) {
			
				let textoFormateado = e.target.result.replace(/\n/g, '<br>');
				contenido.innerHTML = textoFormateado;
	
			};
			lector.onerror = function() {
			contenido.innerHTML = 'EXCEPCI�N: error_de_lectura';
			};
			
			lector.readAsText(archivo);

		} else {
			contenido.innerHTML = 'EXCEPCI�N: archivo_no_encontrado';

		}
});