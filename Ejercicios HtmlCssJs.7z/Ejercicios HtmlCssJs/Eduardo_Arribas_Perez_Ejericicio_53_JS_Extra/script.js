function jugar() {
	
	 let jugador1 = parseInt(document.getElementById("jugador1").value);
	 let jugador2 = parseInt(document.getElementById("jugador2").value);

	switch ( jugador1){
		
		case 1: 
			switch ( jugador2){
			   case 1: parrafo.innerHTML = 'Empate';
			   break;
			   case 2: parrafo.innerHTML = 'Jugador 2 Gana'; 
			   break;
			   case 3: parrafo.innerHTML = 'Jugador 1 Gana'; 
			   break;
			   case 4: parrafo.innerHTML = 'Jugador 1 Gana'; 
			   break;
			   case 5: parrafo.innerHTML = 'Jugador 2 Gana'; 
			   break;
			}
		break;

		case 2:
			switch ( jugador2){
			   case 1: parrafo.innerHTML = 'Jugador 1 Gana'; ; 
			   break;
			   case 2: parrafo.innerHTML = 'Empate';
			   break;
			   case 3: parrafo.innerHTML = 'Jugador 2 Gana'; ; 
			   break;
			   case 4: parrafo.innerHTML = 'Jugador 2 Gana'; 
			   break;
			   case 5: parrafo.innerHTML = 'Jugador 1 Gana'; 
			   break;
			}
		break;

		case 3:
	   switch ( jugador2){
			   case 1:parrafo.innerHTML = 'Jugador 2 Gana';  
			   break;
			   case 2: parrafo.innerHTML = 'Jugador 1 Gana';  
			   break;
			   case 3: parrafo.innerHTML = 'Empate';
			   break;
			   case 4: parrafo.innerHTML = 'Jugador 1 Gana'; 
			   break;
			   case 5: parrafo.innerHTML = 'Jugador 2 Gana'; 
			   break;
			}
		break;
		
		case 4:
	   switch ( jugador2){
			   case 1:parrafo.innerHTML = 'Jugador 1 Gana';  
			   break;
			   case 2: parrafo.innerHTML = 'Jugador 2 Gana';  
			   break;
			   case 3: parrafo.innerHTML = 'Jugador 2 Gana';
			   break;
			   case 4: parrafo.innerHTML = 'Empate'; 
			   break;
			   case 5: parrafo.innerHTML = 'Jugador 1 Gana'; 
			   break;
			}
		break;
		
		case 5:
	   switch ( jugador2){
			   case 1:parrafo.innerHTML = 'Jugador 1 Gana';  
			   break;
			   case 2: parrafo.innerHTML = 'Jugador 2 Gana';  
			   break;
			   case 3: parrafo.innerHTML = 'Jugador 1 Gana';
			   break;
			   case 4: parrafo.innerHTML = 'Jugador 2 Gana'; 
			   break;
			   case 5: parrafo.innerHTML = 'Empate'; 
			   break;
			}
		break;
	}
}
function rendirse(){
	 parrafo.innerHTML = 'Uno de los jugadores se ha Rendido , juego finalizado';
}