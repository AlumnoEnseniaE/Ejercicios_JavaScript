﻿function calcular(){
	
	const numeros = [];
	for (let i = 0; i < 5 ;i++){
		numeros[i] = Math.floor(Math.random() * 10)+1;
	}
	let sumar = 0;

	for(let i = 0; i<numeros.length; i++){
		const numero = numeros[i];
		sumar += numero**2;
	}
	
	document.getElementById('parrafo').innerHTML = 'Los numeros del array son: '+ numeros.join();
	document.getElementById('parrafo1').innerHTML = 'La suma de los cuadrados es: ' +sumar;
}