function par(){
	const num1 = document.getElementById("entrada");
	const parrafo = document.getElementById("parrafo");
	const num2 = parseInt(num1.value, 10);
	const nota = num2/2;
	
	
	if(num2>=0 && num2<=20){
		if(nota>=5){
			parrafo.innerHTML = 'Has aprobado el examen: '+nota+' Bien echo';
		}else{
			parrafo.innerHTML = 'Has suspendido el examen: '+nota+' Tienes que estuidar m�s ';
		}
	}else {
		 parrafo.innerHTML = 'La nota introducida no es correcta y no esta entre 0 y 20';
	}
}